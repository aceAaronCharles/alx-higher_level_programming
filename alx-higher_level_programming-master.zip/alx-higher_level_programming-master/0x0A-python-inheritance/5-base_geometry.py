#!/usr/bin/python3
# 5-base_geometry.py
# Sagebeme
"""Defines an empty class BaseGeometry."""


class BaseGeometry:
    """Represent base geometry."""
    pass
