#!/usr/bin/python3
# 5-raise_exception.py


def raise_exception():
    """Raise a TypeError exception."""
    raise TypeError
