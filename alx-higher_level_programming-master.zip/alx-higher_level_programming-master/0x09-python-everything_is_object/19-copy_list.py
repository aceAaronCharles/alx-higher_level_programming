#!/usr/bin/python3
def copy_list(lis):
    return lis[:]
