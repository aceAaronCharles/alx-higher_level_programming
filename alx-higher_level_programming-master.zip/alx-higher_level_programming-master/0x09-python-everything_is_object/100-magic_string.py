#!/usr/bin/python3
def magic_string(lis=[]):
    lis += ["BestSchool"]
    return ", ".join(lis)
