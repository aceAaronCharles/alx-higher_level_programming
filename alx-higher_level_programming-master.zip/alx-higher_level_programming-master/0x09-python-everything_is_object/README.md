#python everything is an object
