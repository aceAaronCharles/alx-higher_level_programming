def magic_calculation(a, b):
    return (98 + a ** b)
