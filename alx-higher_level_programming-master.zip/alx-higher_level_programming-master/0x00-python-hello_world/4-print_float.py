#!/usr/bin/python3
number = 3.14159
print(f"Float: {number:.2f}")
