#!/usr/bin/python3
# 0-square.py
# Sagebeme
"""Define a class Square."""


class Square:
    """Represent a square."""
    pass
