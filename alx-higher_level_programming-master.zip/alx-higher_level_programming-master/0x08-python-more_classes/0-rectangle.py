#!/usr/bin/python3
# 0-rectangle.py
# Sagebeme
"""Defines a Rectangle class."""


class Rectangle:
    """Represent a rectangle."""
    pass
