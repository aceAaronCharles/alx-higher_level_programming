#!/usr/bin/python3
for lowercase in range(ord('a'), ord('z')+1):
    print("{:c}".format(lowercase), end="")
