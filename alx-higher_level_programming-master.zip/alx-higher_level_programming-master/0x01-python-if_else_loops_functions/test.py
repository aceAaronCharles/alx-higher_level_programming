#!/bin/bash/python3
def my_function():
        print("Counter: is ls here")
my_function