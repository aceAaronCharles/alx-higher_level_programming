#!/usr/bin/python3
# 5-number_keys.py
# Sagebeme


def number_keys(a_dictionary):
    """Return the number of keys in a dictionary."""
    return (len(a_dictionary))
